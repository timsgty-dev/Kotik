import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' работает на GitHub Pages в любом подпути (/repo-name/).
// Если нужен абсолютный путь: VITE_BASE=/repo-name/ npm run build
declare const process: { env: Record<string, string | undefined> };
export default defineConfig({ base: process.env.VITE_BASE ?? './', plugins: [react()] });
