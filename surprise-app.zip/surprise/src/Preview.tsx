import { TIME_ZONE } from './config';

export interface PreviewState { local: string; allOpen: boolean }

/** Панель теста: только в dev-сборке и только с ?preview=1. В production не попадает. */
export function previewEnabled(): boolean {
  return import.meta.env.DEV && new URLSearchParams(window.location.search).get('preview') === '1';
}

export default function PreviewPanel({ value, onChange }: { value: PreviewState; onChange: (v: PreviewState) => void }) {
  return (
    <div className="preview" role="region" aria-label="Тестовый режим">
      <strong>PREVIEW</strong> — время {TIME_ZONE}
      <label>Время:
        <input type="datetime-local" value={value.local} onChange={(e) => onChange({ ...value, local: e.target.value })} />
      </label>
      <label><input type="checkbox" checked={value.allOpen} onChange={(e) => onChange({ ...value, allOpen: e.target.checked })} /> Всё открыто</label>
    </div>
  );
}
