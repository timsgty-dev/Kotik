export interface Recipe { ingredients: string[]; steps: string[] }
export interface Dish {
  id: string;
  title: string;
  /** Локальное время Europe/Warsaw 'YYYY-MM-DDTHH:mm'. null = не задано, карточка закрыта. */
  openAt: string | null;
  /** Путь относительно public/, например 'images/caprese.jpg'. */
  image: string | null;
  recipe: Recipe | null;
}
export interface ActionItem {
  title: string;
  caption: string;
  /** Локальное время начала (Europe/Warsaw). null = пока не задано, запись не используется. */
  startAt: string | null;
  image: string | null;
}
