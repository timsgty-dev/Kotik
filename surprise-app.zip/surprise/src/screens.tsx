import { useEffect, useState } from 'react';
import { ACTIONS, DISHES, MAIN_OPEN_AT, TEXT, TIME_ZONE } from './config';
import { currentAction, formatCountdown, isOpen, msUntil } from './time';
import { loadChecked, saveChecked } from './storage';
import type { Dish } from './types';

const asset = (p: string) => `${import.meta.env.BASE_URL}${p}`;

function Hearts() { return <div className="hearts" aria-hidden="true">♡ ♥ ♡</div>; }

function Photo({ src, alt }: { src: string | null; alt: string }) {
  const [failed, setFailed] = useState(false);
  if (!src || failed) return <div className="photo placeholder" aria-hidden="true">♡</div>;
  return <img className="photo" src={asset(src)} alt={alt} onError={() => setFailed(true)} />;
}

function Back({ onClick }: { onClick: () => void }) {
  return <button className="back" onClick={onClick}>‹ {TEXT.back}</button>;
}

export function Home({ now, forceOpen, go }: { now: number; forceOpen: boolean; go: (s: Screen) => void }) {
  const open = forceOpen || isOpen(MAIN_OPEN_AT, now, TIME_ZONE);
  const left = formatCountdown(msUntil(MAIN_OPEN_AT, now, TIME_ZONE));
  return (
    <main className="screen home">
      <Hearts />
      <p className="intro">{TEXT.homeIntro}</p>
      {open ? (
        <button className="big open" onClick={() => go({ name: 'menu' })}>
          <span className="big-label">{TEXT.homeOpened}</span>
          <span className="big-sub">{TEXT.homeOpenButton}</span>
        </button>
      ) : (
        <div className="big" role="timer" aria-label={`До открытия ${left}`}>
          <span className="time">{left}</span>
        </div>
      )}
      <div className="peek">
        <button className="small" onClick={() => go({ name: 'actions' })}>{TEXT.actionsButton}</button>
      </div>
    </main>
  );
}

export function Actions({ now, back }: { now: number; back: () => void }) {
  const a = currentAction(ACTIONS, now, TIME_ZONE);
  return (
    <main className="screen">
      <Back onClick={back} />
      <h1>{TEXT.actionsTitle}</h1>
      {a ? (
        <section className="card">
          <Photo src={a.image} alt={a.title} />
          <h2>{a.title}</h2>
          {a.caption && <p>{a.caption}</p>}
        </section>
      ) : (
        <section className="card empty"><Hearts /><p>{TEXT.actionsEmpty}</p></section>
      )}
    </main>
  );
}

export function Menu({ now, forceOpen, go, back }: { now: number; forceOpen: boolean; go: (s: Screen) => void; back: () => void }) {
  return (
    <main className="screen">
      <Back onClick={back} />
      <h1>{TEXT.menuTitle}</h1>
      <ul className="dishes">
        {DISHES.map((d, i) => {
          const open = forceOpen || isOpen(d.openAt, now, TIME_ZONE);
          return (
            <li key={d.id}>
              {open ? (
                <button className={`dish c${i % 4}`} onClick={() => go({ name: 'dish', id: d.id })}>
                  <Photo src={d.image} alt={d.title} /><span>{d.title}</span>
                </button>
              ) : (
                <button className={`dish locked c${i % 4}`} disabled aria-label={`Блюдо ${i + 1}: ${TEXT.locked}`}>
                  <span className="lock" aria-hidden="true">🔒</span><span>{TEXT.locked}</span>
                </button>
              )}
            </li>
          );
        })}
      </ul>
    </main>
  );
}

export function DishScreen({ dish, back }: { dish: Dish; back: () => void }) {
  return (
    <main className="screen">
      <Back onClick={back} />
      <h1>{dish.title}</h1>
      <Photo src={dish.image} alt={dish.title} />
      {dish.recipe ? <RecipeView dish={dish} /> : <section className="card empty"><p>{TEXT.recipeEmpty}</p></section>}
    </main>
  );
}

// Готово на будущее: появится само, когда у блюда заполнится recipe.
function RecipeView({ dish }: { dish: Dish }) {
  const r = dish.recipe!;
  const [checked, setChecked] = useState<Record<string, boolean[]>>(loadChecked);
  const [step, setStep] = useState(0);
  const marks = r.ingredients.map((_, i) => Boolean(checked[dish.id]?.[i]));
  useEffect(() => saveChecked(checked), [checked]);
  const toggle = (i: number) => setChecked({ ...checked, [dish.id]: marks.map((m, j) => (j === i ? !m : m)) });
  const last = step >= r.steps.length - 1;
  return (
    <>
      <h2>Ингредиенты</h2>
      <ul className="ingredients">
        {r.ingredients.map((x, i) => (
          <li key={i}><label><input type="checkbox" checked={marks[i]} onChange={() => toggle(i)} /> {x}</label></li>
        ))}
      </ul>
      {r.steps.length > 0 && (
        <section className="card">
          <p className="stepno">Шаг {step + 1} из {r.steps.length}</p>
          <p>{r.steps[step]}</p>
          {last ? <p><strong>Готово! Приятного аппетита ♥</strong></p>
                : <button className="small solid" onClick={() => setStep(step + 1)}>Дальше</button>}
        </section>
      )}
    </>
  );
}

export type Screen = { name: 'home' } | { name: 'actions' } | { name: 'menu' } | { name: 'dish'; id: string };
