const KEY = 'surprise:v1:checked'; // при смене формата увеличьте версию

export function loadChecked(): Record<string, boolean[]> {
  try {
    const raw = localStorage.getItem(KEY);
    const v = raw ? JSON.parse(raw) : {};
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch { return {}; }
}
export function saveChecked(v: Record<string, boolean[]>) {
  try { localStorage.setItem(KEY, JSON.stringify(v)); } catch { /* приватный режим — не критично */ }
}
