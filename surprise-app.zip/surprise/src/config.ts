import type { ActionItem, Dish } from './types';

// ====== ЗДЕСЬ МЕНЯТЬ ДАТУ И ЧАСОВОЙ ПОЯС ======
export const TIME_ZONE = 'Europe/Warsaw';
export const MAIN_OPEN_AT = '2026-10-25T00:00'; // уже в прошлом -> главный экран сразу «открыт»

export const TEXT = {
  homeIntro: 'Для тебя приготовлен сюрприз',
  homeOpened: 'Уже открыто',
  homeOpenButton: 'Открыть меню',
  actionsButton: 'Действия сейчас',
  actionsTitle: 'Действия сейчас',
  actionsEmpty: 'Расписание будет добавлено позже',
  menuTitle: 'Меню',
  locked: 'Откроется позже',
  recipeEmpty: 'Рецепт будет добавлен позже',
  back: 'Назад',
};

// ====== РАСПИСАНИЕ ДЕЙСТВИЙ ======
// Реальные времена пока неизвестны, поэтому startAt = null. Запись начнёт
// работать, когда вы впишете startAt. Названия — из задания, смысл не домысливался.
export const ACTIONS: ActionItem[] = [
  { title: 'zip-zip', caption: '', startAt: null, image: null },
  { title: 'учиться', caption: '', startAt: null, image: null },
  { title: 'в магазине', caption: '', startAt: null, image: null },
  { title: 'готовиться', caption: '', startAt: null, image: null },
  { title: 'ждет расписание позже', caption: '', startAt: null, image: null },
];

// ====== БЛЮДА ======
// openAt задаёт владелец. Пока null — карточка закрыта.
export const DISHES: Dish[] = [
  { id: 'caprese', title: 'Капрезе с бальзамическим соусом', openAt: null, image: null, recipe: null },
  { id: 'tagliatelle', title: 'Тальятелле с креветками', openAt: null, image: null, recipe: null },
  { id: 'tiramisu', title: 'Тирамису', openAt: null, image: null, recipe: null },
  { id: 'lemonade', title: 'Клубничный лимонад', openAt: null, image: null, recipe: null },
];

// Раздел «Буси»: назначение неизвестно, в навигацию не добавлен (см. README).
