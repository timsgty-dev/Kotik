import { useState } from 'react';
import { DISHES, TIME_ZONE } from './config';
import { zonedToUtcMs } from './time';
import { useSystemNow } from './useNow';
import PreviewPanel, { previewEnabled, type PreviewState } from './Preview';
import { Actions, DishScreen, Home, Menu, type Screen } from './screens';

export default function App() {
  const systemNow = useSystemNow();
  const preview = previewEnabled();
  const [pv, setPv] = useState<PreviewState>({ local: '2026-10-24T23:59', allOpen: false });
  const [stack, setStack] = useState<Screen[]>([{ name: 'home' }]);

  // Время для проверок: системное (реальное) или выбранное в preview.
  const now = preview ? (zonedToUtcMs(pv.local, TIME_ZONE) ?? systemNow) : systemNow;
  const forceOpen = preview && pv.allOpen;
  const screen = stack[stack.length - 1];
  const go = (s: Screen) => setStack([...stack, s]);
  const back = () => setStack(stack.length > 1 ? stack.slice(0, -1) : stack);
  const dish = screen.name === 'dish' ? DISHES.find((d) => d.id === screen.id) : undefined;

  return (
    <>
      {preview && <PreviewPanel value={pv} onChange={setPv} />}
      {screen.name === 'home' && <Home now={now} forceOpen={forceOpen} go={go} />}
      {screen.name === 'actions' && <Actions now={now} back={back} />}
      {screen.name === 'menu' && <Menu now={now} forceOpen={forceOpen} go={go} back={back} />}
      {dish && <DishScreen dish={dish} back={back} />}
    </>
  );
}
