/** Все функции чистые: «сейчас» передаётся параметром, поэтому их легко проверять. */

function partsInZone(utcMs: number, tz: string) {
  const f = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit',
    day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit',
  });
  const p: Record<string, number> = {};
  for (const x of f.formatToParts(new Date(utcMs))) if (x.type !== 'literal') p[x.type] = Number(x.value);
  return p;
}

/** Смещение зоны (мс) в данный момент: «локальное время зоны» минус UTC. */
function zoneOffsetMs(utcMs: number, tz: string): number {
  const p = partsInZone(utcMs, tz);
  return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second) - Math.floor(utcMs / 1000) * 1000;
}

/** 'YYYY-MM-DDTHH:mm' в часовом поясе tz -> UTC-миллисекунды (с учётом летнего/зимнего времени). */
export function zonedToUtcMs(local: string, tz: string): number | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(local);
  if (!m) return null;
  const [y, mo, d, h, mi] = m.slice(1).map(Number);
  const asUtc = Date.UTC(y, mo - 1, d, h, mi);
  let guess = asUtc - zoneOffsetMs(asUtc, tz);
  guess = asUtc - zoneOffsetMs(guess, tz); // второй проход — на границе перехода DST
  return guess;
}

/** Открыто ли условие. Не задано или некорректно -> закрыто. */
export function isOpen(openAt: string | null, nowMs: number, tz: string): boolean {
  if (!openAt) return false;
  const t = zonedToUtcMs(openAt, tz);
  return t !== null && nowMs >= t;
}

/** Миллисекунды до события (никогда не отрицательные). */
export function msUntil(openAt: string, nowMs: number, tz: string): number {
  const t = zonedToUtcMs(openAt, tz);
  return t === null ? 0 : Math.max(0, t - nowMs);
}

/** ЧЧ:ММ:СС, часы могут быть больше 24. */
export function formatCountdown(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
}

/** Текущее действие: последнее, у которого startAt уже наступил. Записи без времени игнорируются. */
export function currentAction<T extends { startAt: string | null }>(items: T[], nowMs: number, tz: string): T | null {
  let best: T | null = null, bestT = -Infinity;
  for (const it of items) {
    if (!it.startAt) continue;
    const t = zonedToUtcMs(it.startAt, tz);
    if (t !== null && t <= nowMs && t > bestT) { best = it; bestT = t; }
  }
  return best;
}
